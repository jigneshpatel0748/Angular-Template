export * from '@fuse/services/tailwind/public-api';
